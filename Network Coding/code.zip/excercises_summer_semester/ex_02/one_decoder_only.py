import kodo
import os
import random
import sys



def run(number_relays, idx_recoder, e):
    # Set the number of symbols (i.e. the generation size in RLNC
    # terminology) and the size of a symbol in bytes
    symbols = 42
    symbol_size = 16

    # In the following we will make an encoder/decoder factory.
    # The factories are used to build actual encoders/decoders
    encoder_factory = kodo.FullVectorEncoderFactoryBinary8(
        max_symbols=symbols,
        max_symbol_size=symbol_size)

    encoder = encoder_factory.build()

    decoder_factory = kodo.FullVectorDecoderFactoryBinary8(
        max_symbols=symbols,
        max_symbol_size=symbol_size)

    # We build the recoders
    relays = []
    for i in range(number_relays):
        relays.append(decoder_factory.build())

    # We build the decoder
    decoder = decoder_factory.build()

    # Create some data to encode. In this case we make a buffer
    # with the same size as the encoder's block size (the max.
    # amount a single encoder can encode)
    # Just for fun - fill the input data with random data
    data_in = os.urandom(encoder.block_size())

    # Assign the data buffer to the encoder so that we may start
    # to produce encoded symbols from it
    encoder.set_const_symbols(data_in)

    # Count transferred packets
    txpackets = 0

    while not decoder.is_complete():

        # Encode a packet into the payload buffer
        packet = encoder.write_payload()
        txpackets += 1

        for idx, rel in enumerate(relays):
            # Send the packet to the relay.
            # If there were no losses
            if random.random() > e:
                # If the previous relay forwarded or recoded
                if packet != "":
                    # If the relay is a recoder
                    if idx == idx_recoder:
                        # Give the packet to the recoder
                        rel.read_payload(packet)
            # If there were losses
            else:
                # Make packet empty
                if idx != idx_recoder:
                    packet = ""
            if idx == idx_recoder:
                # Give the packet to the recoder
                packet = rel.write_payload()

        # Pass the recoded packet to decoder
        if random.random() > e:
            if packet != "":
                decoder.read_payload(packet)

    # We Check if data out is correctly decoded
    data_out = decoder.copy_from_symbols()

    # Check we properly decoded the data
    if data_out == data_in:
        return txpackets
    else:
        print("Unexpected failure to decode please file a bug report :)")
        sys.exit(1)


def main():
    runs = 100
    e = 0.3
    # Set the variables of the excercise
    number_relays = 11
    idx_recoder = range(number_relays)

    for idx in idx_recoder:
        results = []
        for i in range(runs):
            results.append(run(number_relays, idx,e))

        mean = sum(results) / float(len(results))
        print("Recoder position: ", idx, 'Average packets: ', mean)

if __name__ == "__main__":
    main()
