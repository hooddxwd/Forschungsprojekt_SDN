# The first step is to import the right module
import socket

# We define some constants like our address and the port where we will listen:
MY_ADDR = "127.0.0.1"
DATA_PORT = 45600
FEEDBACK_PORT = 45601

# Then, we create the socket in just one line :)
sock = socket.socket(socket.AF_INET,  # Inet
                     socket.SOCK_DGRAM)  # UDP

# We bind it to the address
sock.bind((MY_ADDR, DATA_PORT))

received_packets = 0

# We receive data and print it
while received_packets < 10:
    # The argument of the function is the buffer size
    data, sender_addr = sock.recvfrom(2048)
    received_packets += 1
    print 'Received message: ', data, 'From', sender_addr

# Send feedback
sock.sendto('feedback', sender_addr)
print 'Sending feedback to: ', sender_addr
