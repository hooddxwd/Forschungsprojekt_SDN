# The first step is to import the right module
import socket

# We define some constants like the destination address and port:
MY_ADDR = "127.0.0.1"
DEST_ADDR = "127.0.0.1"
DATA_PORT = 45600
FEEDBACK_PORT = 45601
MESSAGE = "Hello World"

# Then, we create the socket in just one line :)
sock = socket.socket(socket.AF_INET,  # Inet
                     socket.SOCK_DGRAM)  # UDP

# We bind it to the address
sock.bind((MY_ADDR, FEEDBACK_PORT))

# The socket needs to be non-blocking
sock.setblocking(0)

has_feedback = False

packets_sent = 0
while not has_feedback and packets_sent < 15:
    # We send the data:
    sock.sendto(MESSAGE, (DEST_ADDR, DATA_PORT))
    packets_sent += 1

    # We check if there is a feedback
    try:
        feedback, address = sock.recvfrom(256)
        if feedback == 'feedback':
            print ('Got feedback')
            break
    except:
        # No feedback received yet
        print 'No feedback yet'
