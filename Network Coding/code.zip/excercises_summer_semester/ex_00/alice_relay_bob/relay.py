import socket

# First, we receive the packets. This is simmilar to the udp_receive.py code

MY_ADDR = "192.168.1.154"
BRDCST_ADDR = "192.168.1.255"
PORT = 45600
XOR = True

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

sock.bind((MY_ADDR, PORT))


def byte(string):
    return [ord(i) for i in string]


def make_word(byte):
    chars = [chr(i) for i in byte]
    return "".join(chars)


def xor(input1, input2):
    return [i ^ j for i, j in zip(input1, input2)]


def disp_bin(int_list):
    return [format(i, '#010b') for i in int_list]

while True:
    # Receive first packet
    data_1, addr_1 = sock.recvfrom(2048)
    print 'Received message: ', data_1, ' from: ', addr_1

    # Receive second packet
    data_2, addr_2 = sock.recvfrom(2048)
    print 'Received message: ', data_2, ' from: ', addr_2

    if XOR:
        byte_1 = byte(data_1)
        print 'Message 1 serialized: ', disp_bin(byte_1)

        byte_2 = byte(data_2)
        print 'Message 2 serialized: ', disp_bin(byte_2)

        byte_enc_data = xor(byte_1, byte_2)
        print 'Encoded data serialized: ', disp_bin(byte_enc_data)

        enc_data = make_word(byte_enc_data)

        # Broadcast coded packet
        sock.sendto(enc_data, (BRDCST_ADDR, PORT))
        print 'One transmission'

    else:
        # Send packet 1 to sender 2
        sock.sendto(data_1, (addr_2[0], PORT))
        print 'Sent ', data_1, ' to ', addr_2, ' first transmission'

        # Send packet 2 to sender 1
        sock.sendto(data_2, (addr_1[0], PORT))
        print 'Sent ', data_2, ' to ', addr_1, ' second transmission'
