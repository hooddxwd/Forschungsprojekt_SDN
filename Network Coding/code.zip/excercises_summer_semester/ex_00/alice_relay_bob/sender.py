import socket

# First, we receive the packets. This is simmilar to the udp_receive.py code

RELAY_ADDR = "192.168.1.154"
PORT = 45600
MY_DATA = 'Hello'
XOR = True

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
bcast_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

bcast_sock.bind(('', PORT))

# Lets define some helper functions


def byte(string):
    return [ord(i) for i in string]


def make_word(byte):
    chars = [chr(i) for i in byte]
    return "".join(chars)


def xor(input1, input2):
    return [i ^ j for i, j in zip(input1, input2)]


def disp_bin(int_list):
    return [format(i, '#010b') for i in int_list]
# ################################################

# Send my data to the relay
sock.sendto(MY_DATA, (RELAY_ADDR, PORT))
print 'Sent ', MY_DATA, ' to ', RELAY_ADDR

# Receive data from relay
rel_addr = ''
while rel_addr != (RELAY_ADDR, PORT):
    rel_data, rel_addr = bcast_sock.recvfrom(2048)
# print 'Received message: ', rel_data, ' from: ', rel_addr

# Decode?
if XOR:
    byte_rel_data = byte(rel_data)
    print 'Received data from relay: ', disp_bin(byte_rel_data)

    # Decode
    dec_data = make_word(xor(byte_rel_data, byte(MY_DATA)))
    print 'Decoded data: ', dec_data

else:
    print 'Received message: ', rel_data, ' from: ', rel_addr
