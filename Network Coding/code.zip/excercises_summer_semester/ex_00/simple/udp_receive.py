# The first step is to import the right module
import socket

# We define some constants like our address and the port where we will listen:
MY_ADDR = "10.0.0.141"
PORT = 45600

# Then, we create the socket in just one line :)
sock = socket.socket(socket.AF_INET,  # Inet
                     socket.SOCK_DGRAM)  # UDP

# We bind it to the address
sock.bind((MY_ADDR, PORT))

# We receive data and print it
while True:
    # The argument of the function is the buffer size
    data, addr = sock.recvfrom(2048)
    print 'Received message: ', data
