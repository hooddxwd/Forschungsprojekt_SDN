# The first step is to import the right module
import socket

# We define some constants like the destination address and port:
IP_ADDR = "192.168.1.255"
PORT = 45600
MESSAGE = "Hello World"

# Then, we create the socket in just one line :)
sock = socket.socket(socket.AF_INET,  # Inet
                     socket.SOCK_DGRAM)  # UDP

# If we want to broadcast data, we need to give permissions to the socket
sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

# We send the data:
sock.sendto(MESSAGE, (IP_ADDR, PORT))
